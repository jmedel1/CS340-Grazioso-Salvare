"""
CRUD Python module for the AAC database.
This file includes basic create and read functions
for working with the 'animals' collection in MongoDB.
"""

from pymongo import MongoClient
from pymongo.errors import ConnectionFailure


class AnimalShelter:
    # This class handles the database connection and CRUD operations.

    def __init__(self, username, password):
        """
        Connect to MongoDB using the username and password passed in.
        """
        try:
            # Build the connection string. The database requires authentication
            # against the admin database for this assignment.
            connection = f"mongodb://{username}:{password}@localhost:27017/?authSource=admin"
            self.client = MongoClient(connection)

            # Use the AAC database
            self.database = self.client["aac"]

        except ConnectionFailure:
            # If something goes wrong connecting to MongoDB
            raise Exception("Could not connect to MongoDB.")

    # -----------------------------------------------------------
    # CREATE
    # -----------------------------------------------------------
    def create(self, data):
        """
        Insert a single document into the animals collection.
        Returns True if insert worked, otherwise False.
        """
        if data is None or not isinstance(data, dict):
            # Data must be a dictionary for MongoDB to insert it.
            return False

        try:
            result = self.database.animals.insert_one(data)
            # MongoDB returns an inserted_id if the insert succeeded
            return result.inserted_id is not None

        except Exception as e:
            print("Create error:", e)
            return False

    # -----------------------------------------------------------
    # READ
    # -----------------------------------------------------------
    def read(self, query):
        """
        Query the animals collection using the provided dictionary.
        Returns a list of matching documents. If something fails,
        returns an empty list.
        """
        if query is None or not isinstance(query, dict):
            return []

        try:
            cursor = self.database.animals.find(query)
            results = list(cursor)
            return results

        except Exception as e:
            print("Read error:", e)
            return []
